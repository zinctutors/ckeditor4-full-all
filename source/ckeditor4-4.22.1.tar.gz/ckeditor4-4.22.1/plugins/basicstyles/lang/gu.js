/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'gu', {
	bold: 'બોલ્ડ/સ્પષ્ટ',
	italic: 'ઇટેલિક, ત્રાંસા',
	strike: 'છેકી નાખવું',
	subscript: 'એક ચિહ્નની નીચે કરેલું બીજું ચિહ્ન',
	superscript: 'એક ચિહ્ન ઉપર કરેલું બીજું ચિહ્ન.',
	underline: 'અન્ડર્લાઇન, નીચે લીટી'
} );
